import React from 'react'

const Cart = () => {
  return (
    <div>
      <h2  className="text-center" style={{ padding: "10rem" }}> CART PAGE</h2>
    </div>
  )
}

export default Cart
