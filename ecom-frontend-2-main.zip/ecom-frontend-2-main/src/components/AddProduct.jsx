import React from 'react'

const AddProduct = () => {
  return (
    <div>
      <h2 className="text-center" style={{ padding: "10rem" }}> Add Product</h2>
    </div>
  )
}

export default AddProduct
