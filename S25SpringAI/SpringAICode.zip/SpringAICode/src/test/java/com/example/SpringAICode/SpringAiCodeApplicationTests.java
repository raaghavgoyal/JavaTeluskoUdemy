package com.example.SpringAICode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAiCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
