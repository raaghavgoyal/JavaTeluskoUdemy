package com.example.SpringAICode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAiCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAiCodeApplication.class, args);
	}

}
