import './App.css';
import Search from './components/Search';

function App() {
  return (
    <div>
      <Search/>
    </div>
  );
}

export default App;
